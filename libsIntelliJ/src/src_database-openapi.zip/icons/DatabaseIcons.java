package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run build/scripts/icons.gant instead
 */
public class DatabaseIcons {
  private static Icon load(String path) {
    return IconLoader.getIcon(path, DatabaseIcons.class);
  }

  public static final Icon Add_hover = load("/icons/add-hover.png"); // 10x10
  public static final Icon Add = load("/icons/add.png"); // 10x10
  public static final Icon AddRow = load("/icons/addRow.png"); // 16x16
  public static final Icon Argument = load("/icons/argument.png"); // 16x16
  public static final Icon BlueKey = load("/icons/blueKey.png"); // 16x16
  public static final Icon Body = load("/icons/body.png"); // 16x16
  public static final Icon Catalog = load("/icons/catalog.png"); // 16x16
  public static final Icon CheckConstraint = load("/icons/checkConstraint.png"); // 16x16
  public static final Icon Col = load("/icons/col.png"); // 16x16
  public static final Icon ColBlueKey = load("/icons/colBlueKey.png"); // 16x16
  public static final Icon ColBlueKeyDot = load("/icons/colBlueKeyDot.png"); // 16x16
  public static final Icon ColBlueKeyDotIndex = load("/icons/colBlueKeyDotIndex.png"); // 16x16
  public static final Icon ColBlueKeyIndex = load("/icons/colBlueKeyIndex.png"); // 16x16
  public static final Icon ColDot = load("/icons/colDot.png"); // 16x16
  public static final Icon ColDotIndex = load("/icons/colDotIndex.png"); // 16x16
  public static final Icon ColGoldBlueKey = load("/icons/colGoldBlueKey.png"); // 16x16
  public static final Icon ColGoldBlueKeyDot = load("/icons/colGoldBlueKeyDot.png"); // 16x16
  public static final Icon ColGoldBlueKeyDotIndex = load("/icons/colGoldBlueKeyDotIndex.png"); // 16x16
  public static final Icon ColGoldBlueKeyIndex = load("/icons/colGoldBlueKeyIndex.png"); // 16x16
  public static final Icon ColGoldKey = load("/icons/colGoldKey.png"); // 16x16
  public static final Icon ColGoldKeyDot = load("/icons/colGoldKeyDot.png"); // 16x16
  public static final Icon ColGoldKeyDotIndex = load("/icons/colGoldKeyDotIndex.png"); // 16x16
  public static final Icon ColGoldKeyIndex = load("/icons/colGoldKeyIndex.png"); // 16x16
  public static final Icon ColIndex = load("/icons/colIndex.png"); // 16x16
  public static final Icon CollectionType = load("/icons/collectionType.png"); // 16x16
  public static final Icon Commit = load("/icons/commit.png"); // 16x16
  public static final Icon Connector = load("/icons/connector.png"); // 16x16
  public static final Icon ConsoleRun = load("/icons/consoleRun.png"); // 16x16
  public static final Icon ConsoleRunHover = load("/icons/consoleRunHover.png"); // 16x16
  public static final Icon ConsoleShowPlan = load("/icons/consoleShowPlan.png"); // 16x16
  public static final Icon Constant = load("/icons/constant.png"); // 16x16
  public static final Icon Database = load("/icons/database.png"); // 16x16
  public static final Icon DatabaseGroup = load("/icons/databaseGroup.png"); // 16x16
  public static final Icon Dbms = load("/icons/dbms.png"); // 16x16
  public static final Icon DdlDbms = load("/icons/ddlDbms.png"); // 16x16
  public static final Icon ExportDDL = load("/icons/exportDDL.png"); // 16x16
  public static final Icon ExportSQL = load("/icons/exportSQL.png"); // 16x16
  public static final Icon FileGroup = load("/icons/fileGroup.png"); // 16x16
  public static final Icon FilterAndOrder = load("/icons/filterAndOrder.png"); // 16x16
  public static final Icon Function = load("/icons/function.png"); // 16x16
  public static final Icon GoldBlueKey = load("/icons/goldBlueKey.png"); // 16x16
  public static final Icon GoldKey = load("/icons/goldKey.png"); // 16x16
  public static final Icon GoldKeyAlt = load("/icons/goldKeyAlt.png"); // 16x16
  public static final Icon Index = load("/icons/index.png"); // 16x16
  public static final Icon IndexUnique = load("/icons/indexUnique.png"); // 16x16
  public static final Icon ManageDataSources = load("/icons/manageDataSources.png"); // 16x16
  public static final Icon MaterializedView = load("/icons/materializedView.png"); // 16x16
  public static final Icon ObjectGroup = load("/icons/objectGroup.png"); // 16x16
  public static final Icon ObjecType = load("/icons/objecType.png"); // 16x16
  public static final Icon ObjecTypeAttribute = load("/icons/objecTypeAttribute.png"); // 16x16
  public static final Icon Operator = load("/icons/operator.png"); // 16x16
  public static final Icon Package = load("/icons/package.png"); // 16x16
  public static final Icon Play_back = load("/icons/play_back.png"); // 16x16
  public static final Icon Play_first = load("/icons/play_first.png"); // 16x16
  public static final Icon Play_forward = load("/icons/play_forward.png"); // 16x16
  public static final Icon Play_last = load("/icons/play_last.png"); // 16x16
  public static final Icon Procedure = load("/icons/procedure.png"); // 16x16
  public static final Icon ProcGroup = load("/icons/procGroup.png"); // 16x16
  public static final Icon RemoveRow = load("/icons/removeRow.png"); // 16x16
  public static final Icon Rollback = load("/icons/rollback.png"); // 16x16
  public static final Icon Routine = load("/icons/routine.png"); // 16x16
  public static final Icon Rule = load("/icons/rule.png"); // 16x16
  public static final Icon Schema = load("/icons/schema.png"); // 16x16
  public static final Icon SchemaRefresh = load("/icons/schemaRefresh.png"); // 16x16
  public static final Icon SchemaRefreshHover = load("/icons/schemaRefreshHover.png"); // 16x16
  public static final Icon Sequence = load("/icons/sequence.png"); // 16x16
  public static final Icon Sql = load("/icons/sql.png"); // 16x16
  public static final Icon SqlDdlStatement = load("/icons/sqlDdlStatement.png"); // 16x16
  public static final Icon SqlDmlStatement = load("/icons/sqlDmlStatement.png"); // 16x16
  public static final Icon SqlGroupByType = load("/icons/sqlGroupByType.png"); // 16x16
  public static final Icon SqlOtherStatement = load("/icons/sqlOtherStatement.png"); // 16x16
  public static final Icon SqlSelectStatement = load("/icons/sqlSelectStatement.png"); // 16x16
  public static final Icon Synonym = load("/icons/synonym.png"); // 16x16
  public static final Icon Table = load("/icons/table.png"); // 16x16
  public static final Icon ToolWindowConsole = load("/icons/toolWindowConsole.png"); // 13x13
  public static final Icon ToolWindowDatabase = load("/icons/toolWindowDatabase.png"); // 13x13
  public static final Icon ToolWindowFiles = load("/icons/toolWindowFiles.png"); // 13x13
  public static final Icon Trigger = load("/icons/trigger.png"); // 16x16
  public static final Icon UserDriver = load("/icons/userDriver.png"); // 16x16
  public static final Icon Variable = load("/icons/variable.png"); // 16x16
  public static final Icon View = load("/icons/view.png"); // 16x16
}
