/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.database.model;

import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.containers.ContainerUtil;
import org.intellij.lang.annotations.MagicConstant;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.Serializable;
import java.sql.Types;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import static com.intellij.database.util.DbUtil.intern2;

/**
 * Type of one datum.
 * <p/>
 * Value object.
 */
public final class DataType implements Serializable {

  /**
   * For fields like varchar(max).
   */
  public static final int MAX_SIZE = Integer.MAX_VALUE;

  /**
   * For fields like number(*) or varchar(*).
   */
  public static final int STAR_SIZE = Integer.MAX_VALUE - 1;

  /**
   * For fields like int or date, where the size is not specified.
   */
  public static final int NO_SIZE = -1;

  public static final DataType UNKNOWN = new DataType(null, "unknown", NO_SIZE, 0, LengthUnit.NONE,
                                                      null, null, false, false,
                                                      Collections.emptyList(),
                                                      Collections.emptySet(), Types.NULL);

  public enum Feature {
    isBoolean,
    isNumber,
    isText,
    isCollection,
    isStruct,

    comparable,
    orderable,
    alwaysNotNull,

  }

  @NotNull
  public final Set<Feature> features;

  /**
   * Name of the schema.
   * Null for common/internal types.
   */
  @Nullable
  public final String schemaName;

  /**
   * Name of the type (without schema prefix).
   *
   * @see #schemaName
   */
  @NotNull
  public final String typeName;

  /**
   * Size or precision of the type.
   * <p/>
   * <p>
   * Contains the size of datum, or one of the following 'magic' values:
   * <ul>
   * <li>{@link #STAR_SIZE} mean '<b>*</b>';</li>
   * <li>{@link #MAX_SIZE} means '<b>max</b>';</li>
   * <li>{@link #NO_SIZE} means the size is not specified.</li>
   * </ul>
   * </p>
   *
   * @see #sizeUnit
   * @see #scale
   */
  @MagicConstant(intValues = {STAR_SIZE, MAX_SIZE, NO_SIZE})
  public final int size;

  /**
   * Scale, or 0 if N/A.
   *
   * @see #size
   */
  public final int scale;

  /**
   * Unit of size (as declared in code, if possible to determine).
   *
   * @see #size
   */
  @NotNull
  public final LengthUnit sizeUnit;

  /**
   * Indefinite argument inside parentheses.
   * For example, in "geometry(point,4126)" it's "point,4126"
   */
  public final String vagueArg;

  /**
   * A rest part of the type that is written after the closing parenthesis.
   */
  @Nullable
  public final String suffix;

  /**
   * The size units are specified explicitly;
   */
  public final boolean sizeUnitExplicit;

  /**
   * The type is defined by a user.
   */
  public final boolean custom;

  /**
   * Enumeration value.
   */
  @Nullable
  public final List<String> enumValues;


  @Deprecated  //todo REMOVEME ASAP
  public final int jdbcType;


  DataType(@Nullable String schemaName,
           @NotNull String typeName,
           @MagicConstant(intValues = {STAR_SIZE, MAX_SIZE, NO_SIZE})
           int size,
           int scale,
           @Nullable LengthUnit sizeUnit,
           @Nullable String vagueArg,
           @Nullable String suffix,
           boolean sizeUnitExplicit,
           boolean custom,
           @Nullable List<String> enumValues,
           @NotNull Set<Feature> features,
           int jdbcType) {
    this.features = features;
    this.schemaName = intern2(schemaName);
    this.typeName = intern2(typeName);
    this.size = size;
    this.scale = scale;
    this.sizeUnit = sizeUnit != null ? sizeUnit : LengthUnit.NONE;
    this.vagueArg = intern2(vagueArg);
    this.suffix = intern2(suffix);
    this.custom = custom;
    this.sizeUnitExplicit = sizeUnitExplicit;
    this.jdbcType = jdbcType;
      
    this.enumValues = enumValues == null || enumValues.isEmpty()
                      ? null
                      : ContainerUtil.immutableList(enumValues);
  }

  //todo: DdlBuilder#type(DataType)
  @NotNull
  public String getSpecification() {
    if (schemaName == null && vagueArg == null && enumValues == null && size < 0 && suffix == null) {
      return typeName;
    }

    StringBuilder sb = new StringBuilder(12);
    if (schemaName != null) {
      sb.append(schemaName).append('.');
    }

    sb.append(typeName);

    if (vagueArg != null) {
      sb.append('(').append(vagueArg).append(')');
    }
    else if (enumValues != null) {
      sb.append('(');
      StringUtil.join(enumValues, ", ", sb);
      sb.append(')');
    }
    else if (size >= 0) {
      sb.append('(');
      if (size == STAR_SIZE) {
        sb.append('*');
      }
      else if (size == MAX_SIZE) {
        sb.append("max");
      }
      else {
        sb.append(size);
      }
      if (scale != 0) {
        sb.append(',').append(scale);
      }
      if (sizeUnit != LengthUnit.NONE && sizeUnitExplicit) {
        sb.append(' ').append(sizeUnit.suffix.toLowerCase(Locale.ENGLISH));
      }
      sb.append(')');
    }
    if (suffix != null) {
      sb.append(' ').append(suffix);
    }

    return sb.toString();
  }

  public int getLength() {
    return size;
  }

  public int getPrecision() {
    return size;
  }

  public int getScale() {
    return scale;
  }

  @Override
  public boolean equals(Object that) {
    if (this == that) return true;
    if (that == null || getClass() != that.getClass()) return false;
    return equals((DataType)that);
  }

  public boolean equals(@NotNull DataType that) {
    if (this == that) return true;

    if (!StringUtil.equals(this.schemaName, that.schemaName)) return false;
    if (!StringUtil.equals(this.vagueArg, that.vagueArg)) return false;
    if (!StringUtil.equals(this.typeName, that.typeName)) return false;
    if (!StringUtil.equals(this.suffix, that.suffix)) return false;
    if (!typeName.equals(that.typeName)) return false;
    if (size != that.size) return false;
    if (scale != that.scale) return false;
    if (sizeUnit != that.sizeUnit) return false;
    if (custom != that.custom) return false;
    if (jdbcType != that.jdbcType) return false;
    if ((enumValues == null) != (that.enumValues == null)) return false;
    if (enumValues != null && !Comparing.haveEqualElements(enumValues, that.enumValues)) return false;

    return true;
  }

  @Override
  public int hashCode() {
    return typeName.hashCode() * 29 + jdbcType * 17 + size * 7 + scale * 5 + sizeUnit.hashCode() * 3 + (enumValues != null ? enumValues.hashCode() : 0);
  }

  @Override
  public String toString() {
    return getSpecification();
  }

}
