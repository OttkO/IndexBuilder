package com.intellij.database.view.generators;

import com.intellij.database.extensions.Binding;
import com.intellij.database.psi.DbElement;
import com.intellij.openapi.project.Project;
import com.intellij.util.containers.JBIterable;

public interface DatabaseViewExtensionScriptsBindings {
  Binding<Project>                 PROJECT = new Binding<Project>("PROJECT");
  Binding<JBIterable<DbElement>> SELECTION = new Binding<JBIterable<DbElement>>("SELECTION");
  Binding<Clipboard>             CLIPBOARD = new Binding<Clipboard>("CLIPBOARD");
  Binding<Logger>                      LOG = new Binding<Logger>("LOG");
  Binding<Files>                     FILES = new Binding<Files>("FILES");
}
