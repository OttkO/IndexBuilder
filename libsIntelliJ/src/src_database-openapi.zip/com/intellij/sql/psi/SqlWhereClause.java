package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlWhereClause extends SqlQueryClause {
}