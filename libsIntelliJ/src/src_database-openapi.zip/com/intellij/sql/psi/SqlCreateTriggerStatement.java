package com.intellij.sql.psi;

import com.intellij.database.model.DasTrigger;

/**
 * @author Gregory.Shrago
 */
public interface SqlCreateTriggerStatement extends SqlCreateStatement, SqlTargetContextProvider, DasTrigger {
}