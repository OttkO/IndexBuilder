package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlSetOperatorExpression extends SqlBinaryExpression, SqlResultSetExpression {
}