package com.intellij.sql.psi;

import java.util.List;

/**
 * @author Gregory.Shrago
 */
public interface SqlDmlStatement extends SqlStatement{
  List<SqlDmlInstruction> getDmlInstructions();
}
