package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public abstract class SqlPrimitiveType extends SqlType {

  public boolean isPrimitive() {
    return true;
  }
}