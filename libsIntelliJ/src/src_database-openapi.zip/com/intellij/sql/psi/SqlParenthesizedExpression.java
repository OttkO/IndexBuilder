package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlParenthesizedExpression extends SqlExpression, SqlExpressionList {
}
