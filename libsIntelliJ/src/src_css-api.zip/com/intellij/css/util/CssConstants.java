package com.intellij.css.util;

import com.intellij.psi.css.descriptor.CssMediaGroup;
import org.jetbrains.annotations.NonNls;

public final class CssConstants {
  @NonNls public static final String AND = "and";
  @NonNls public static final String NOT = "not";
  @NonNls public static final String ANY = "any";
  @NonNls public static final String UNUSED = "unused";
  @NonNls public static final String ONLY = "only";
  @NonNls public static final String OR = "or";
  
  @NonNls public static final String SUPPORTS = "supports";
  
  @NonNls public static final String SEMICOLON = ";";

  @NonNls public static final String INHERIT_VALUE = "inherit";
  @NonNls public static final String ATTR_FUNCTION_NAME = "attr";
  @NonNls public static final String CALC_FUNCTION_NAME = "calc";
  public static final CssMediaGroup[] DEFAULT_MEDIA_GROUPS = new CssMediaGroup[]{CssMediaGroup.ALL};
  public static final String TOGGLE_FUNCTION_NAME = "toggle";
  public static final String VAR_FUNCTION_NAME = "var";
  public static final String IMAGE_FUNCTION_NAME = "image";

  private CssConstants() {
  }
}
