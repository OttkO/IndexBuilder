package com.intellij.psi.css;

/**
 * User: zolotov
 * Date: 6/21/13
 */
public interface CssSupportsConditionList extends CssSupportsCondition {
  CssSupportsCondition[] getConditions();
}
