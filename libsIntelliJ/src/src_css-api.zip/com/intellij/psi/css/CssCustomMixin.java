package com.intellij.psi.css;

import com.intellij.psi.NavigatablePsiElement;

public interface CssCustomMixin extends CssNamedElement, CssOneLineStatement, NavigatablePsiElement {
}
