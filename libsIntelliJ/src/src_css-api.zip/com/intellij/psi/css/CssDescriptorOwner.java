package com.intellij.psi.css;

import com.intellij.psi.PsiElement;
import com.intellij.psi.css.descriptor.CssElementDescriptor;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;

/**
 * User: zolotov
 * Date: 3/22/13
 */
public interface CssDescriptorOwner extends CssElement {

  @NotNull
  Collection<? extends CssElementDescriptor> getDescriptors();
  
  @NotNull
  Collection<? extends CssElementDescriptor> getDescriptors(@NotNull PsiElement context);
}
