package com.intellij.psi.css.descriptor.value;

import org.jetbrains.annotations.NotNull;

/**
 * User: zolotov
 * Date: 7/10/13
 */
public interface CssValueDescriptorVisitor {
  void visitValue(@NotNull CssValueDescriptor value);
}
