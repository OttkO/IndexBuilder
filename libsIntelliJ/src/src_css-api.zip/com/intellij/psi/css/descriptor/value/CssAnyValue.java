package com.intellij.psi.css.descriptor.value;

/**
 * User: zolotov
 * Date: 7/9/13
 * <p/>
 * Describes value that can be ANY css. Uses as a stub for any value.
 */
public interface CssAnyValue extends CssValueDescriptor {
}
