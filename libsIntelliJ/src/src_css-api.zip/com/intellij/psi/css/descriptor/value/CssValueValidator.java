package com.intellij.psi.css.descriptor.value;

import com.intellij.psi.PsiElement;

/**
 * User: zolotov
 * Date: 7/12/13
 */
public interface CssValueValidator {
  boolean isValid(PsiElement value, CssValueDescriptor valueDescriptor);
}
