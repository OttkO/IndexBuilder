package com.intellij.psi.css.descriptor;

/**
 * User: zolotov
 * Date: 3/13/13
 */
public interface CssPseudoClassDescriptor extends CssPseudoSelectorDescriptor {
}
