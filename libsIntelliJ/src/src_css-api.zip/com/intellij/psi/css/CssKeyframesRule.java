package com.intellij.psi.css;

import com.intellij.psi.PsiNameIdentifierOwner;

/**
 * User: zolotov
 * Date: 9/14/12
 */
public interface CssKeyframesRule extends CssAtRule, PsiNameIdentifierOwner {
}
