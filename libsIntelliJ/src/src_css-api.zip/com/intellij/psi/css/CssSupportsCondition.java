package com.intellij.psi.css;

/**
 * User: zolotov
 * Date: 6/20/13
 */
public interface CssSupportsCondition extends CssElement {
}
