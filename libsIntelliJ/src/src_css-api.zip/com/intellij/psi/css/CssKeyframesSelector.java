package com.intellij.psi.css;

/**
 * User: zolotov
 * Date: 9/14/12
 */
public interface CssKeyframesSelector extends CssSimpleSelector {
}
