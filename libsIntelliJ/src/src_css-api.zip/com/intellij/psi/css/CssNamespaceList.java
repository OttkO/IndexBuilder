package com.intellij.psi.css;

/**
 * User: zolotov
 * Date: 8/18/13
 */
public interface CssNamespaceList extends CssElement {
  CssNamespace[] getNamespaces();
}
