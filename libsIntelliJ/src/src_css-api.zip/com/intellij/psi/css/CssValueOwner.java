package com.intellij.psi.css;

import com.intellij.openapi.util.TextRange;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface CssValueOwner extends CssElement {
  @Nullable
  CssTermList getValue();

  @NotNull
  TextRange getTrimmedValueTextRange();
  
  @NotNull
  TextRange getValueTextRange();
}
