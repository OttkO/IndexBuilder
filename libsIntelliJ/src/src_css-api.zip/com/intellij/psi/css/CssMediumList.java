package com.intellij.psi.css;

import com.intellij.psi.css.descriptor.CssMediaType;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

/**
 * @author Eugene.Kudelevsky
 */
public interface CssMediumList extends CssElement {

  @NotNull
  CssMediaQuery[] getMediaQueries();
  
  @NotNull
  Set<CssMediaType> getTypes();
}
