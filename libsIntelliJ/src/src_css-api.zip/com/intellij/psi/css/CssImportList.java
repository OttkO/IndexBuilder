package com.intellij.psi.css;

import java.util.List;

/**
 * User: zolotov
 * Date: 4/26/13
 */
public interface CssImportList extends CssElement {
  List<CssImport> getImports();
}
