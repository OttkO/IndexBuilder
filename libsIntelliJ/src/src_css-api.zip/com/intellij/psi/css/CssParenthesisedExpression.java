package com.intellij.psi.css;

public interface CssParenthesisedExpression extends CssTerm {
}
