/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.web.facet;

import com.intellij.facet.*;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.javaee.model.xml.web.WebApp;
import com.intellij.javaee.model.enums.WebAppVersion;
import com.intellij.javaee.web.WebModel;
import com.intellij.javaee.web.WebRoot;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiDirectory;
import com.intellij.util.descriptors.ConfigFile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * @author nik
 */                    
public abstract class WebFacet extends JavaeeFacet {
  public static final FacetTypeId<WebFacet> ID = new FacetTypeId<WebFacet>("web");


  protected WebFacet(@NotNull final FacetType facetType, @NotNull final Module module, final String name, @NotNull final FacetConfiguration configuration,
                     final Facet underlyingFacet) {
    super(facetType, module, name, configuration, underlyingFacet);
  }

  @NotNull
  public static Collection<WebFacet> getInstances(@NotNull Module module) {
    return FacetManager.getInstance(module).getFacetsByType(ID);
  }

  public abstract WebRoot addWebRoot(@NotNull String directoryUrl, @NotNull String relativePath);
  public abstract WebRoot addWebRoot(@NotNull VirtualFile directory, @NotNull String relativePath);
  public abstract void removeWebRoot(WebRoot webRoot);
  public abstract void removeAllWebRoots();

  public abstract WebRoot addWebRootNoFire(@NotNull String directoryUrl, @NotNull String relativePath);

  public abstract List<WebRoot> getWebRoots();

  public abstract List<WebRoot> getWebRoots(boolean includeDependentModules);

  /**
   * Merged model for web.xml and all web fragments.
   * Should be used for read access only.
   * @see #getWebApps()
   */
  @Nullable
  public abstract WebApp getRoot();

  public abstract List<WebApp> getWebApps();

  @NotNull
  public abstract WebAppVersion getWebAppVersion();

  @NotNull
  public abstract WebModel getWebModel();

  public abstract List<PsiDirectory> getResources();

  public abstract Map<String, String> getTaglibUriToResourceMap();

  @Nullable
  public abstract ConfigFile getWebXmlDescriptor();

  public abstract void addWebSourceRoot(@NotNull String url);
  public abstract void removeWebSourceRoot(@NotNull String url);
  public abstract void setWebSourceRoots(@NotNull String[] urls);

  public abstract List<String> getWebSourceRootUrls();

  public abstract Collection<VirtualFile> getSourceRoots();
}
