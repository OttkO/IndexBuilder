/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.util;

import com.intellij.icons.AllIcons;
import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * @author peter
 */
public class JavaeeIcons implements PlatformIcons {
  public static final Icon WEB_FOLDER_CLOSED = AllIcons.Nodes.WebFolder;
  @Deprecated public static final Icon WEB_FOLDER_OPEN = WEB_FOLDER_CLOSED;

  public static final Icon EJB_CLASS_ICON = AllIcons.Javaee.EjbClass;
  public static final Icon EJB_INTERCEPTOR_CLASS_ICON = AllIcons.Javaee.InterceptorClass;
  public static final Icon EJB_HOME_INTERFACE_ICON = AllIcons.Javaee.Home;
  public static final Icon EJB_LOCAL_HOME_INTERFACE_ICON = AllIcons.Javaee.LocalHome;
  public static final Icon EJB_LOCAL_INTERFACE_ICON = AllIcons.Javaee.Local;
  public static final Icon EJB_REMOTE_INTERFACE_ICON = AllIcons.Javaee.Remote;
  public static final Icon EJB_ICON = AllIcons.Nodes.Ejb;
  public static final Icon EJB_CREATE_METHOD_ICON = AllIcons.Nodes.EjbCreateMethod;
  public static final Icon EJB_FINDER_METHOD_ICON = AllIcons.Nodes.EjbFinderMethod;
  public static final Icon EJB_BUSINESS_METHOD_ICON = AllIcons.Nodes.EjbBusinessMethod;
  public static final Icon EJB_CMP_FIELD_ICON = AllIcons.Nodes.EjbCmpField;
  public static final Icon EJB_CMR_FIELD_ICON = AllIcons.Nodes.EjbCmrField;
  public static final Icon EJB_PRIMARY_KEY_CLASS = AllIcons.Nodes.EjbPrimaryKeyClass;
  public static final Icon EJB_REFERENCE = AllIcons.Nodes.EjbReference;
  public static final Icon EJB_FIELD_PK = AllIcons.Nodes.FieldPK;

  public static final Icon SESSION_BEAN = AllIcons.Javaee.SessionBean;
  public static final Icon ENTITY_BEAN = AllIcons.Javaee.EntityBean;
  public static final Icon MESSAGE_BEAN = AllIcons.Javaee.MessageBean;
  public static final Icon EJB_INTERCEPTOR_METHOD_ICON = AllIcons.Javaee.InterceptorMethod;
  public static final Icon JPA_ICON = AllIcons.Javaee.JpaFacet;
  public static final Icon RELATIONSHIP_ICON = AllIcons.Javaee.PersistenceRelationship;
  public static final Icon ID_RELATIONSHIP_ICON = AllIcons.Javaee.PersistenceIdRelationship;
  public static final Icon ATTRIBUTE_ICON = AllIcons.Javaee.PersistenceAttribute;
  public static final Icon ID_ATTRIBUTE_ICON = AllIcons.Javaee.PersistenceId;
  public static final Icon ENTITY_ICON = AllIcons.Javaee.PersistenceEntity;
  public static final Icon MAPPED_SUPERCLASS_ICON = AllIcons.Javaee.PersistenceMappedSuperclass;
  public static final Icon EMBEDDABLE_ICON = AllIcons.Javaee.PersistenceEmbeddable;
  public static final Icon ENTITY_LISTENER_ICON = AllIcons.Javaee.PersistenceEntityListener;
  public static final Icon PERSISTENCE_UNIT_ICON = AllIcons.Javaee.PersistenceUnit;
  public static final Icon EJB_JAR = AllIcons.Javaee.Ejb_jar_xml;
  public static final Icon EJB_MODULE_BIG = AllIcons.Modules.Types.EjbModule;
  public static final Icon EJB_MODULE_SMALL = AllIcons.Javaee.EjbModule;
  public static final Icon APPLICATION_XML = AllIcons.Javaee.Application_xml;
  public static final Icon APP_MODULE_BIG = AllIcons.Modules.Types.JavaeeAppModule;
  public static final Icon APP_MODULE_SMALL = AllIcons.Javaee.JavaeeAppModule;
  public static final Icon WEB_XML = AllIcons.Javaee.Web_xml;
  public static final Icon WEB_MODULE_BIG = AllIcons.Modules.Types.WebModule;
  public static final Icon WEB_MODULE_SMALL = AllIcons.Javaee.WebModule;
  public static final Icon EJBQL_METHOD_GUTTER_ICON = AllIcons.Gutter.ImplementedMethod;
  public static final Icon DB_SCHEMA_IMPORT_BIG = AllIcons.Javaee.DbSchemaImportBig;
  public static final Icon DATASOURCE_REMOTE_INSTANCE = AllIcons.ToolbarDecorator.AddRemoteDatasource;
}
