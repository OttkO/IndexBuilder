/*
 * Copyright 2000-2013 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model.converters;

import com.intellij.codeInsight.daemon.impl.quickfix.CreateMethodQuickFix;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.psi.CommonClassNames;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.PsiModifier;
import com.intellij.psi.scope.processor.MethodResolveProcessor;
import com.intellij.util.xml.ConvertContext;
import com.intellij.util.xml.GenericDomValue;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class SpringBeanMethodConverter extends PsiMethodConverter {

  protected MethodAccepter getMethodAccepter(final ConvertContext context, final boolean forCompletion) {
    return new MethodAccepter() {

      public boolean accept(PsiMethod method) {
        if (method.isConstructor()) return false;

        final PsiClass containingClass = method.getContainingClass();
        if (containingClass == null) return false;
        final String containing = containingClass.getQualifiedName();
        if (CommonClassNames.JAVA_LANG_OBJECT.equals(containing)) return false;

        return checkParameterList(method) && checkModifiers(method) && checkReturnType(context, method, forCompletion);
      }
    };
  }

  protected boolean checkModifiers(final PsiMethod method) {
    return method.hasModifierProperty(PsiModifier.PUBLIC) && !method.hasModifierProperty(PsiModifier.ABSTRACT);
  }

  protected boolean checkParameterList(final PsiMethod method) {
    return method.getParameterList().getParametersCount() == 0;
  }

  protected boolean checkReturnType(final ConvertContext context, final PsiMethod method, final boolean forCompletion) {
    return true;
  }

  public LocalQuickFix[] getQuickFixes(final ConvertContext context) {
      final GenericDomValue element = (GenericDomValue)context.getInvocationElement();

      final String elementName = element.getStringValue();
      final PsiClass beanClass = getPsiClass(context);
      if (elementName != null && elementName.length() > 0 && beanClass != null) {
        LocalQuickFix fix = createNewMethodQuickFix(beanClass, elementName, context);

        return fix == null ? LocalQuickFix.EMPTY_ARRAY : new LocalQuickFix[] {fix};
      }

    return LocalQuickFix.EMPTY_ARRAY;
  }

  @Nullable
  private static LocalQuickFix createNewMethodQuickFix(@NotNull final PsiClass beanClass,
                                                       final String elementName,
                                                       final ConvertContext context) {
    return CreateMethodQuickFix.createFix(beanClass, getNewMethodSignature(elementName, context), beanClass.isInterface() ? "" : getNewMethodBody(elementName, context));
  }

  @NonNls
  protected static String getNewMethodSignature(final String elementName, final ConvertContext context) {
    return "public void " + elementName + "()";
  }

  @NonNls
  protected static String getNewMethodBody(final String elementName, final ConvertContext context) {
    return "";
  }

  @Override
  protected String getMethodIdentificator(PsiMethod method) {
    return method.getName();
  }

  @Override
  protected PsiMethod[] getMethodCandidates(String methodIdentificator, PsiClass psiClass) {
    return MethodResolveProcessor.findMethod(psiClass, methodIdentificator);
  }
}