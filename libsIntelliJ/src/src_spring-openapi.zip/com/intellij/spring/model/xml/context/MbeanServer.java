/*
 * Copyright 2000-2014 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Generated on Wed Oct 17 15:28:10 MSD 2007
// DTD/Schema  :    http://www.springframework.org/schema/context

package com.intellij.spring.model.xml.context;

import com.intellij.spring.model.xml.BeanName;
import com.intellij.spring.model.xml.BeanType;
import com.intellij.spring.model.xml.DomSpringBean;
import com.intellij.spring.model.xml.FallBackBeanNameProvider;
import com.intellij.util.xml.GenericAttributeValue;
import org.jetbrains.annotations.NotNull;

/**
 * @@updated: spring-context-4.1.xsd
 */
@BeanType(MbeanServer.FACTORY_CLASSNAME)
@BeanName(provider = MbeanServer.MbeanServerBeanNameProvider.class)
public interface MbeanServer extends DomSpringBean, SpringContextElement {
  String FACTORY_CLASSNAME = "org.springframework.jmx.support.MBeanServerFactoryBean";
  String PRODUCT_CLASSNAME = "javax.management.MBeanServer";

  String DEFAULT_BEAN_NAME = "mbeanServer";

  class MbeanServerBeanNameProvider extends FallBackBeanNameProvider<MbeanServer> {
    public MbeanServerBeanNameProvider() {
      super(DEFAULT_BEAN_NAME);
    }
  }

  @NotNull
  GenericAttributeValue<String> getAgentId();
}
