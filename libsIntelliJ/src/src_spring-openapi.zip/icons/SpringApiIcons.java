/*
 * Copyright 2000-2014 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run build/scripts/icons.gant instead
 */
public class SpringApiIcons {
  private static Icon load(String path) {
    return IconLoader.getIcon(path, SpringApiIcons.class);
  }

  public static final Icon AbtractBean = load("/icons/abtractBean.png"); // 16x16
  public static final Icon ChildBeanGutter = load("/icons/childBeanGutter.png"); // 16x16
  public static final Icon FactoryMethodBean = load("/icons/factoryMethodBean.png"); // 16x16
  public static final Icon FileSet = load("/icons/fileSet.png"); // 16x16
  public static final Icon ImplicitBean = load("/icons/implicitBean.png"); // 16x16
  public static final Icon InfrastructureBean = load("/icons/infrastructureBean.png"); // 16x16
  public static final Icon Listener = load("/icons/listener.png"); // 16x16
  public static final Icon ParentBeanGutter = load("/icons/parentBeanGutter.png"); // 16x16
  public static final Icon PrototypeBean = load("/icons/prototypeBean.png"); // 16x16
  public static final Icon Publisher = load("/icons/publisher.png"); // 16x16
  public static final Icon ShowAutowiredDependencies = load("/icons/showAutowiredDependencies.png"); // 16x16
  public static final Icon ShowCacheable = load("/icons/showCacheable.png"); // 16x16
  public static final Icon Spring = load("/icons/spring.png"); // 16x16
  public static final Icon SpringBean = load("/icons/springBean.png"); // 16x16
  public static final Icon SpringBeanMethod = load("/icons/springBeanMethod.png"); // 16x16
  public static final Icon SpringConfig = load("/icons/springConfig.png"); // 16x16
  public static final Icon SpringJavaBean = load("/icons/springJavaBean.png"); // 16x16
  public static final Icon SpringJavaConfig = load("/icons/springJavaConfig.png"); // 16x16
  public static final Icon SpringProfile = load("/icons/SpringProfile.png"); // 16x16
  public static final Icon SpringProperty = load("/icons/springProperty.png"); // 16x16
  public static final Icon SpringToolWindow = load("/icons/springToolWindow.png"); // 13x13
}
